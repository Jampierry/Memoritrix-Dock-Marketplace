var f=[{id:"sinapse",nome:"Sinapse"},{id:"midia",nome:"M\xEDdia"},{id:"notas",nome:"Notas"},{id:"monitor",nome:"Monitor"}],I="sinapse",S=t=>f.find(a=>a.id===t)?.id??I;function b(t){if(!Number.isFinite(t)||t<0)return"\u2014";let a=1024*1024;return t>=1024*a?`${(t/(1024*a)).toFixed(1).replace(".",",")} GB`:`${Math.round(t/a)} MB`}var y=(t,a)=>a>0&&Number.isFinite(t)?Math.min(100,Math.max(0,Math.round(t/a*100))):0;function T(t){let a=t.trim();return a?{titulo:(a.split(`
`)[0]??"").replace(/^#+\s*/,"").trim().slice(0,60)||"Nota r\xE1pida",texto:a}:null}var k=`/* Gaveta (#gaveta e #gaveta-trilho): trilho fino na borda direita e gaveta que desliza, em tons suaves de lavanda. S\xF3 estas duas janelas carregam este arquivo. */
html, body, #root { background: transparent !important; overflow: hidden; }

.gv, .gv-trilho {
  --gv-sf: rgba(22, 23, 34, 0.94); --gv-sf2: rgba(255, 255, 255, 0.06); --gv-tx: #ebecf3; --gv-mu: #a0a5bd; --gv-ln: rgba(255, 255, 255, 0.12);
  --gv-ax: #b9a4fb; --gv-ax-bg: rgba(167, 139, 250, 0.2); --gv-sombra: 0 18px 44px rgba(0, 0, 0, 0.45);
  font-family: 'Segoe UI Variable Text', 'Segoe UI', system-ui, sans-serif; color: var(--gv-tx);
}
.gv[data-style='D'], .gv-trilho[data-style='D'] {
  --gv-sf: rgba(255, 255, 255, 0.96); --gv-sf2: rgba(70, 60, 120, 0.07); --gv-tx: #1c1d28; --gv-mu: #636a82; --gv-ln: rgba(40, 40, 80, 0.14);
  --gv-ax: #6d4fd6; --gv-ax-bg: rgba(124, 92, 230, 0.14); --gv-sombra: 0 18px 44px rgba(40, 50, 90, 0.2);
}

/* Trilho: a faixa quase invis\xEDvel; fica mais viva quando o mouse chega */
.gv-trilho { width: 100%; height: calc(100vh / var(--gv-esc, 1)); display: flex; align-items: center; justify-content: flex-end; cursor: pointer; }
.gv-trilho i { display: block; width: 4px; height: 56%; margin-right: 3px; border-radius: 4px; background: var(--gv-ax); opacity: 0.28; transition: opacity 0.2s, width 0.2s; }
.gv-trilho:hover i { opacity: 0.95; width: 7px; }

/* Gaveta */
.gv { width: 100%; height: calc(100vh / var(--gv-esc, 1)); padding: 10px; box-sizing: border-box; overflow: hidden; --bg: var(--gv-sf); --card: var(--gv-sf2); --mt: var(--gv-mu); --tx: var(--gv-tx); --font: 'Segoe UI Variable Text', 'Segoe UI', system-ui, sans-serif; --dur: 0.25s; --accent: var(--gv-ax); }
.gv-cartao { height: 100%; box-sizing: border-box; display: flex; flex-direction: column; background: var(--gv-sf); border: 1px solid var(--gv-ln); border-radius: 18px; box-shadow: var(--gv-sombra); backdrop-filter: blur(var(--blur, 24px)); overflow: hidden; transform: translateX(calc(100% + 40px)); opacity: 0; transition: transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.2s; }
.gv-cartao.aberta { transform: none; opacity: 1; }
@media (prefers-reduced-motion: reduce) { .gv-cartao, .gv-trilho i { transition: none; } }

.gv-abas { display: flex; align-items: center; gap: 2px; padding: 10px 10px 6px; flex: none; }
.gv-abas button { all: unset; cursor: pointer; padding: 5px 11px; border-radius: 999px; font-size: 12.5px; font-weight: 600; color: var(--gv-mu); }
.gv-abas button:hover { background: var(--gv-sf2); color: var(--gv-tx); }
.gv-abas button.on { background: var(--gv-ax-bg); color: var(--gv-ax); }
.gv-abas button:focus-visible { outline: 2px solid var(--gv-ax); outline-offset: 1px; }
.gv-esp { flex: 1; }
.gv-abas .gv-x { font-size: 18px; line-height: 1; padding: 3px 9px; }
.gv-corpo { flex: 1; min-height: 0; overflow: auto; padding: 8px 16px 16px; }

.gv-dica { color: var(--gv-mu); font-size: 12.5px; line-height: 1.5; margin: 6px 0 12px; }
.gv-sinapse h3, .gv-monitor h3 { margin: 4px 0 0; font-size: 15px; font-weight: 700; }

.gv-midia { padding-top: 4px; }

.gv-notas { height: 100%; display: flex; flex-direction: column; gap: 10px; }
.gv-notas textarea { flex: 1; min-height: 120px; resize: none; box-sizing: border-box; background: var(--gv-sf2); color: inherit; border: 1px solid var(--gv-ln); border-radius: 12px; padding: 10px 12px; font: 13.5px/1.5 inherit; outline: none; }
.gv-notas textarea:focus { border-color: var(--gv-ax); }

.gv-monitor { display: grid; gap: 14px; padding-top: 4px; }
.gv-med-t { display: flex; justify-content: space-between; font-size: 12.5px; margin-bottom: 5px; }
.gv-med-t span { color: var(--gv-mu); }
.gv-barra { height: 7px; border-radius: 6px; background: var(--gv-sf2); overflow: hidden; }
.gv-barra i { display: block; height: 100%; border-radius: 6px; background: var(--gv-ax); transition: width 0.4s; }
.gv-app { display: flex; justify-content: space-between; align-items: baseline; padding: 10px 12px; border-radius: 12px; background: var(--gv-sf2); font-size: 13px; }
.gv-app b { font-size: 18px; color: var(--gv-ax); }
`;var E="gaveta:aba",A="gaveta:nota",G=t=>{try{return window.localStorage.getItem(t)??""}catch{return""}},w=(t,a)=>{try{window.localStorage.setItem(t,a)}catch{}};function P(t){let a=t.React,{useCallback:M,useEffect:p,useRef:z,useState:l}=a,C=t.componentes.AbaMidia,c=(e,...s)=>t.invocar(e,...s).then(n=>n);function D(){let[e,s]=l(null),[n,v]=l(null);return p(()=>{c("gaveta:painel-ativo").then(g=>{s(g.dados===!0),g.dados===!0&&c("gaveta:sinapse-info").then(r=>{r.ok&&r.dados&&v(r.dados)}).catch(()=>{})}).catch(()=>s(!1))},[]),e===null?a.createElement(a.Fragment,null):e?a.createElement("div",{className:"gv-sinapse"},a.createElement("h3",null,"Sinapse"),a.createElement("p",{className:"gv-dica"},n?`${n.notas} ${n.notas===1?"nota aprendida":"notas aprendidas"}${n.atualizadoEm?`, atualizado em ${new Date(n.atualizadoEm).toLocaleDateString("pt-BR")}`:""}.`:"Suas notas, conex\xF5es e a busca da Sinapse."),a.createElement("button",{className:"gv-btn",onClick:()=>t.enviar({t:"sinapse"})},"Abrir o painel da Sinapse")):a.createElement("p",{className:"gv-dica"},"O m\xF3dulo Painel (Sinapse) est\xE1 desligado. Ligue-o em Ajustes, na parte de m\xF3dulos, para usar este atalho.")}function L(){let[e,s]=l(!1),[n,v]=l(()=>G(A)),[g,r]=l(""),d=z(null);p(()=>{c("gaveta:painel-ativo").then(o=>s(o.dados===!0)).catch(()=>{})},[]),p(()=>{let o=window.setTimeout(()=>d.current?.focus(),380);return()=>window.clearTimeout(o)},[]);let u=o=>{v(o),r(""),w(A,o)},m=M(async()=>{let o=T(n);if(!o){r("Escreva algo antes de guardar.");return}if(!e){r("Nota guardada s\xF3 neste computador (rascunho). Ligue o m\xF3dulo Painel para envi\xE1-las \xE0 Sinapse.");return}try{let x=await c("gaveta:nota",o.titulo,o.texto);x.ok?(v(""),w(A,""),r("Nota enviada para a Sinapse.")):r(x.erro??"N\xE3o consegui guardar a nota.")}catch{r("N\xE3o consegui guardar a nota.")}},[n,e]);return a.createElement("div",{className:"gv-notas"},a.createElement("textarea",{ref:d,value:n,onChange:o=>u(o.target.value),placeholder:"Anote uma ideia r\xE1pida\u2026","aria-label":"Nota r\xE1pida",spellCheck:!1}),a.createElement("div",{className:"gv-linha"},a.createElement("small",null,g||(e?"Vai para a Sinapse.":"Rascunho local (m\xF3dulo Painel desligado).")),a.createElement("button",{className:"gv-btn",onClick:()=>void m()},e?"Enviar para a Sinapse":"Guardar rascunho")))}function h({rotulo:e,valor:s,detalhe:n}){return a.createElement("div",{className:"gv-med"},a.createElement("div",{className:"gv-med-t"},a.createElement("span",null,e),a.createElement("b",null,n)),a.createElement("div",{className:"gv-barra"},a.createElement("i",{style:{width:`${s}%`}})))}function $(){let[e,s]=l(null),[n,v]=l(0),[g,r]=l([]);return p(()=>{let d=0,u=()=>{document.visibilityState!=="hidden"&&(c("gaveta:metricas").then(o=>{o.dados&&s(o.dados)}).catch(()=>{}),c("gaveta:ram").then(o=>v(o.dados??0)).catch(()=>{}),d++%10===0&&c("gaveta:unidades").then(o=>r((o.dados??[]).slice(0,3))).catch(()=>{}))};u();let m=window.setInterval(u,2e3);return()=>window.clearInterval(m)},[]),a.createElement("div",{className:"gv-monitor"},a.createElement(h,{rotulo:"CPU",valor:e?.cpu??0,detalhe:e?`${e.cpu}%`:"\u2026"}),a.createElement(h,{rotulo:"Mem\xF3ria",valor:e?y(e.memUsada,e.memTotal):0,detalhe:e?`${b(e.memUsada)} de ${b(e.memTotal)}`:"\u2026"}),g.map(d=>a.createElement(h,{key:d.letra,rotulo:`Disco ${d.letra}`,valor:y(d.total-d.livre,d.total),detalhe:`${b(d.livre)} livres`})),a.createElement("div",{className:"gv-app"},a.createElement("span",null,"Memoritrix Dock"),a.createElement("b",null,n?b(n):"\u2026")),a.createElement("small",{className:"gv-dica"},"Soma de todas as janelas do app. As leituras s\xF3 rodam com esta aba \xE0 vista."))}return function(){let[s,n]=l(null),[v,g]=l(!1),[r,d]=l(()=>S(G(E)));p(()=>(t.config.obter().then(n),t.config.aoMudar(i=>n(i))),[]),p(()=>(c("gaveta:aberta").then(i=>g(i.dados===!0)).catch(()=>{}),t.aoReceber(i=>{let N=i;N?.t==="estado"&&g(N.aberta===!0)})),[]);let[u,m]=l(!1);p(()=>{if(v){m(!0);return}let i=window.setTimeout(()=>m(!1),320);return()=>window.clearTimeout(i)},[v]);let o=i=>{d(i),w(E,i)},x=i=>{i.key==="Escape"&&(i.preventDefault(),t.enviar({t:"fechar"}))};return s?a.createElement("div",{className:"gv","data-style":s.estilo,style:{zoom:t.escala,"--gv-esc":t.escala},onKeyDown:x},a.createElement("style",null,k),a.createElement("section",{className:`gv-cartao${v?" aberta":""}`,role:"dialog","aria-label":"Gaveta"},a.createElement("nav",{className:"gv-abas",role:"tablist"},f.map(i=>a.createElement("button",{key:i.id,role:"tab","aria-selected":r===i.id,className:r===i.id?"on":"",onClick:()=>o(i.id)},i.nome)),a.createElement("span",{className:"gv-esp"}),a.createElement("button",{className:"gv-x","aria-label":"Fechar a gaveta",onClick:()=>t.enviar({t:"fechar"})},"\xD7")),a.createElement("div",{className:"gv-corpo"},u&&r==="sinapse"&&a.createElement(D,null),u&&r==="midia"&&a.createElement(C,null),u&&r==="notas"&&a.createElement(L,null),u&&r==="monitor"&&a.createElement($,null)))):null}}export{P as default};
