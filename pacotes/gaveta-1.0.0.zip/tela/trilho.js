var t=`/* Gaveta (#gaveta e #gaveta-trilho): trilho fino na borda direita e gaveta que desliza, em tons suaves de lavanda. S\xF3 estas duas janelas carregam este arquivo. */
html, body, #root { background: transparent !important; overflow: hidden; }

.gv, .gv-trilho {
  --gv-sf: rgba(22, 23, 34, 0.94); --gv-sf2: rgba(255, 255, 255, 0.06); --gv-tx: #ebecf3; --gv-mu: #a0a5bd; --gv-ln: rgba(255, 255, 255, 0.12);
  --gv-ax: #b9a4fb; --gv-ax-bg: rgba(167, 139, 250, 0.2); --gv-sombra: 0 18px 44px rgba(0, 0, 0, 0.45);
  font-family: 'Segoe UI Variable Text', 'Segoe UI', system-ui, sans-serif; color: var(--gv-tx);
}
.gv[data-style='D'], .gv-trilho[data-style='D'] {
  --gv-sf: rgba(255, 255, 255, 0.96); --gv-sf2: rgba(70, 60, 120, 0.07); --gv-tx: #1c1d28; --gv-mu: #636a82; --gv-ln: rgba(40, 40, 80, 0.14);
  --gv-ax: #6d4fd6; --gv-ax-bg: rgba(124, 92, 230, 0.14); --gv-sombra: 0 18px 44px rgba(40, 50, 90, 0.2);
}

/* Trilho: a faixa quase invis\xEDvel; fica mais viva quando o mouse chega */
.gv-trilho { width: 100%; height: calc(100vh / var(--gv-esc, 1)); display: flex; align-items: center; justify-content: flex-end; cursor: pointer; }
.gv-trilho i { display: block; width: 4px; height: 56%; margin-right: 3px; border-radius: 4px; background: var(--gv-ax); opacity: 0.28; transition: opacity 0.2s, width 0.2s; }
.gv-trilho:hover i { opacity: 0.95; width: 7px; }

/* Gaveta */
.gv { width: 100%; height: calc(100vh / var(--gv-esc, 1)); padding: 10px; box-sizing: border-box; overflow: hidden; --bg: var(--gv-sf); --card: var(--gv-sf2); --mt: var(--gv-mu); --tx: var(--gv-tx); --font: 'Segoe UI Variable Text', 'Segoe UI', system-ui, sans-serif; --dur: 0.25s; --accent: var(--gv-ax); }
.gv-cartao { height: 100%; box-sizing: border-box; display: flex; flex-direction: column; background: var(--gv-sf); border: 1px solid var(--gv-ln); border-radius: 18px; box-shadow: var(--gv-sombra); backdrop-filter: blur(var(--blur, 24px)); overflow: hidden; transform: translateX(calc(100% + 40px)); opacity: 0; transition: transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1), opacity 0.2s; }
.gv-cartao.aberta { transform: none; opacity: 1; }
@media (prefers-reduced-motion: reduce) { .gv-cartao, .gv-trilho i { transition: none; } }

.gv-abas { display: flex; align-items: center; gap: 2px; padding: 10px 10px 6px; flex: none; }
.gv-abas button { all: unset; cursor: pointer; padding: 5px 11px; border-radius: 999px; font-size: 12.5px; font-weight: 600; color: var(--gv-mu); }
.gv-abas button:hover { background: var(--gv-sf2); color: var(--gv-tx); }
.gv-abas button.on { background: var(--gv-ax-bg); color: var(--gv-ax); }
.gv-abas button:focus-visible { outline: 2px solid var(--gv-ax); outline-offset: 1px; }
.gv-esp { flex: 1; }
.gv-abas .gv-x { font-size: 18px; line-height: 1; padding: 3px 9px; }
.gv-corpo { flex: 1; min-height: 0; overflow: auto; padding: 8px 16px 16px; }

.gv-dica { color: var(--gv-mu); font-size: 12.5px; line-height: 1.5; margin: 6px 0 12px; }
.gv-sinapse h3, .gv-monitor h3 { margin: 4px 0 0; font-size: 15px; font-weight: 700; }

.gv-midia { padding-top: 4px; }

.gv-notas { height: 100%; display: flex; flex-direction: column; gap: 10px; }
.gv-notas textarea { flex: 1; min-height: 120px; resize: none; box-sizing: border-box; background: var(--gv-sf2); color: inherit; border: 1px solid var(--gv-ln); border-radius: 12px; padding: 10px 12px; font: 13.5px/1.5 inherit; outline: none; }
.gv-notas textarea:focus { border-color: var(--gv-ax); }

.gv-monitor { display: grid; gap: 14px; padding-top: 4px; }
.gv-med-t { display: flex; justify-content: space-between; font-size: 12.5px; margin-bottom: 5px; }
.gv-med-t span { color: var(--gv-mu); }
.gv-barra { height: 7px; border-radius: 6px; background: var(--gv-sf2); overflow: hidden; }
.gv-barra i { display: block; height: 100%; border-radius: 6px; background: var(--gv-ax); transition: width 0.4s; }
.gv-app { display: flex; justify-content: space-between; align-items: baseline; padding: 10px 12px; border-radius: 12px; background: var(--gv-sf2); font-size: 13px; }
.gv-app b { font-size: 18px; color: var(--gv-ax); }
`;function v(a){let r=a.React,{useEffect:i,useState:g}=r;return function(){let[e,o]=g(null);return i(()=>(a.config.obter().then(o),a.config.aoMudar(n=>o(n))),[]),e?r.createElement("div",{className:"gv-trilho","data-style":e.estilo,style:{zoom:a.escala,"--gv-esc":a.escala},onPointerEnter:()=>a.enviar({t:"perto",perto:!0}),onPointerLeave:()=>a.enviar({t:"perto",perto:!1}),onClick:()=>a.enviar({t:"clique"}),role:"button","aria-label":"Abrir a gaveta",title:"Abrir a gaveta"},r.createElement("style",null,t),r.createElement("i",null)):null}}export{v as default};
